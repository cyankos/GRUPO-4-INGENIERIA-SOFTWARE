package com.example.appiot

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EstadoTendederoTest {
    @Test
    fun lluviaRecogeElTendederoConModoAutomatico() {
        val mojado = EstadoTendedero.DEMO_INICIAL.simularLluvia()

        assertTrue(mojado.lluvia == true)
        assertTrue(mojado.recogido == true)
        assertEquals("650", mojado.sensor)
        assertEquals("88.0", mojado.humedad)
        assertEquals("17.8", mojado.temperatura)

        val seco = mojado.simularLluvia()
        assertFalse(seco.lluvia == true)
        assertEquals("0", seco.sensor)
        assertTrue(seco.recogido == true)
    }

    @Test
    fun activarAutomaticoCuandoYaLlueveRecogeElTendedero() {
        val mojado = EstadoTendedero.DEMO_INICIAL.simularComando("AUTO_OFF").simularLluvia()

        assertEquals(false, mojado.recogido)
        val conAutomatico = mojado.simularComando("AUTO_ON")
        assertEquals(true, conAutomatico.automatico)
        assertEquals(true, conAutomatico.recogido)
    }

    @Test
    fun demoPermiteControlManualYAlertasIndependientes() {
        val recogido = EstadoTendedero.DEMO_INICIAL.simularComando("CERRAR")
        val abierto = recogido.simularComando("ABRIR")
        val buzzerApagado = abierto.simularComando("BUZZER_OFF")
        val ledApagado = buzzerApagado.simularComando("LED_OFF")

        assertEquals(true, recogido.recogido)
        assertEquals(false, abierto.recogido)
        assertEquals(false, buzzerApagado.buzzer)
        assertEquals(true, buzzerApagado.led)
        assertEquals(false, ledApagado.led)
        assertEquals(true, ledApagado.simularComando("LED_ON").led)
        assertEquals(true, ledApagado.simularComando("BUZZER_ON").buzzer)
        assertEquals(ledApagado, ledApagado.simularComando("ESTADO"))
    }

    @Test
    fun lecturaArduinoParteSinValoresSimuladosYActualizaCadaDato() {
        val inicial = EstadoTendedero()
        assertNull(inicial.lluvia)
        assertNull(inicial.recogido)
        assertEquals("--", inicial.sensor)

        val lecturas = listOf(
            " LLUVIA:1 ", "SENSOR:650", "HUM:88.0", "TEMP:-5.2",
            "TENDEDERO:RECOGIDO", "BUZZER:OFF", "LED:ON", "AUTO:OFF"
        )
        val estado = lecturas.fold(inicial, EstadoTendedero::aplicarLectura)

        assertEquals(EstadoTendedero(true, "650", "88.0", "-5.2", true, false, true, false), estado)
        assertEquals(false, estado.aplicarLectura("LLUVIA:0").lluvia)
        assertEquals(false, estado.aplicarLectura("TENDEDERO:ABIERTO").recogido)
    }

    @Test
    fun fallaDhtRetiraLasLecturasAnteriores() {
        val medido = EstadoTendedero().aplicarLectura("HUM:68.5").aplicarLectura("TEMP:15.3")
        val sinDht = medido.aplicarLectura("HUM:NA").aplicarLectura("TEMP:NA")

        assertEquals("--", sinDht.humedad)
        assertEquals("--", sinDht.temperatura)
    }

    @Test
    fun lecturasFueraDeRangoYMensajesDesconocidosConservanElEstado() {
        val estado = EstadoTendedero.DEMO_INICIAL
        val ruidos = listOf(
            "", "SENSOR:1024", "SENSOR:-1", "SENSOR:error", "HUM:102",
            "TEMP:-45", "TEMP:NaN", "LLUVIA:2", "AUTO:error", "OK:ABRIR", "ERROR:MENSAJE_LARGO"
        )

        assertEquals(estado, ruidos.fold(estado, EstadoTendedero::aplicarLectura))
    }
}
