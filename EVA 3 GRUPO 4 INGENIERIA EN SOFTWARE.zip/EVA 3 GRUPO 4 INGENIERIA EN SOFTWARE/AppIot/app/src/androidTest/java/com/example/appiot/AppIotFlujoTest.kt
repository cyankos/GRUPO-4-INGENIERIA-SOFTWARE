package com.example.appiot

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class AppIotFlujoTest {
    @Test
    fun iniciaYVerificaCuentaSesionEHistorial() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val auth = AuthStore(context)
        val anterior = auth.currentEmail()
        val email = "appiot-${UUID.randomUUID()}@example.test"
        val clave = "PruebaIoT-U4"

        try {
            auth.logout()
            ActivityScenario.launch(MainActivity::class.java).use { scenario ->
                scenario.onActivity { assertFalse(AuthStore(it).hasSession()) }
            }
            assertFalse(auth.login(email, clave))
            assertNull(auth.register(email, clave))
            assertEquals(email, AuthStore(context).currentEmail())
            assertEquals("Ese correo ya está registrado", auth.register(email.uppercase(), clave))

            ActivityScenario.launch(MainActivity::class.java).use { scenario ->
                scenario.recreate()
                scenario.onActivity { assertEquals(email, AuthStore(it).currentEmail()) }
            }

            val evento = EventoUi("09:41", "Lluvia detectada", "Simulación")
            HistorialStore(context).guardar(email, listOf(evento))
            assertEquals(listOf(evento), HistorialStore(context).leer(email))
            assertTrue(HistorialStore(context).leer("otro-$email").isEmpty())

            auth.logout()
            assertFalse(AuthStore(context).hasSession())
            assertFalse(auth.login(email, "Clave incorrecta"))
            assertTrue(auth.login(email, clave))
        } finally {
            val authPrefs = context.getSharedPreferences("appiot_auth", 0)
            val emailKey = authPrefs.all.entries.firstOrNull { it.value == email && it.key.endsWith("_email") }?.key
            val editor = authPrefs.edit()
            if (emailKey != null) {
                val id = emailKey.removeSuffix("_email")
                listOf("email", "salt", "algo", "hash").forEach { editor.remove("${id}_$it") }
            }
            if (anterior.isBlank()) editor.remove("active_session")
            else editor.putString("active_session", anterior)
            editor.commit()
            context.getSharedPreferences("appiot_historial", 0).edit().remove(email).commit()
        }
    }
}

