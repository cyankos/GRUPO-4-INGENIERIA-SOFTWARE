package com.example.appiot

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasClickAction
import androidx.compose.ui.test.hasContentDescription
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextReplacement
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.util.UUID

@RunWith(AndroidJUnit4::class)
class EvaluacionIswTest {
    @get:Rule
    val compose = createAndroidComposeRule<MainActivity>()

    @Test
    fun registroIngresoCierreYModoRealSinDispositivo() {
        val ctx = compose.activity.applicationContext
        val auth = AuthStore(ctx)
        val previous = auth.currentEmail()
        val address = "qa-${UUID.randomUUID()}@example.test"
        val password = "PruebaLocal-2026"
        try {
            auth.logout()
            compose.activityRule.scenario.recreate()
            tap("Iniciar sesión")
            see("Completa correo y contraseña")
            tap("Crear cuenta")
            compose.onNodeWithTag("registration-email").performTextReplacement(address)
            compose.onNodeWithTag("registration-password").performTextReplacement(password)
            compose.onNodeWithTag("registration-confirmation").performTextReplacement("OtraClave-2026")
            tap("Registrar cuenta")
            see("Las contraseñas no coinciden")
            compose.onNodeWithTag("registration-confirmation").performTextReplacement(password)
            tap("Registrar cuenta")
            see("Mis dispositivos")

            compose.onNode(hasText("Conexión") and hasClickAction()).performClick()
            compose.onNode(hasContentDescription("Modo demostración") and hasClickAction()).performClick()
            compose.onNodeWithText("Solicitar estado").assertIsNotEnabled()
            compose.onNode(hasText("Inicio") and hasClickAction()).performScrollTo().performClick()
            compose.onAllNodesWithText("Sin confirmar").onFirst().assertIsDisplayed()
            compose.onNodeWithText("Abrir").performScrollTo().assertIsNotEnabled()
            compose.onNodeWithText("Recoger").performScrollTo().assertIsNotEnabled()

            compose.activityRule.scenario.recreate()
            compose.onAllNodesWithText("Sin confirmar").onFirst().assertIsDisplayed()
            compose.onNodeWithText("Cerrar sesión").performScrollTo().performClick()
            see("Iniciar sesión")
            compose.onNodeWithTag("login-email").performTextReplacement(address)
            compose.onNodeWithTag("login-password").performTextReplacement("Incorrecta-2026")
            tap("Iniciar sesión")
            see("Correo o contraseña incorrectos")
            compose.onNodeWithTag("login-password").performTextReplacement(password)
            tap("Iniciar sesión")
            see("Demo / desconectado")
        } finally {
            removeAccount(ctx, address)
            restoreSession(ctx, previous)
        }
    }

    @Test
    fun mantenedorCompletoYNavegacion() {
        val ctx = compose.activity.applicationContext
        val address = "qa-${UUID.randomUUID()}@example.test"
        val previous = AuthStore(ctx).currentEmail()
        AuthStore(ctx).register(address, "PruebaLocal-2026")
        try {
            compose.activityRule.scenario.recreate()
            tap("Mis dispositivos")
            see("Todavía no tienes dispositivos registrados.")
            tap("Agregar dispositivo")
            tap("Guardar dispositivo")
            see("Escribe un nombre de 3 a 40 caracteres")
            see("Escribe una ubicación de 2 a 60 caracteres")
            fillDevice("Tendedero patio", "Patio trasero")
            compose.onNodeWithTag("device-address").performTextReplacement("42")
            tap("Guardar dispositivo")
            see("Usa una MAC válida, por ejemplo 12:34:56:78:9A:BC")
            compose.onNodeWithTag("device-address").performTextReplacement("12:34:56:78:9a:bc")
            tap("Guardar dispositivo")
            see("Dispositivo agregado correctamente")
            see("Tendedero patio")
            see("Patio trasero")
            see("12:34:56:78:9A:BC")

            tap("Agregar dispositivo")
            fillDevice("tendedero PATIO", "Jardín")
            tap("Guardar dispositivo")
            see("Ya existe un dispositivo con ese nombre")
            tap("Cancelar")

            tap("Editar")
            fillDevice("Tendedero patio", "")
            tap("Guardar cambios")
            see("Escribe una ubicación de 2 a 60 caracteres")
            fillDevice("Tendedero terraza", "Terraza norte")
            tap("Guardar cambios")
            see("Cambios guardados correctamente")
            see("Tendedero terraza")
            see("Terraza norte")

            compose.activityRule.scenario.recreate()
            tap("Mis dispositivos")
            see("Terraza norte")
            tap("Eliminar")
            tap("Cancelar")
            see("Tendedero terraza")
            tap("Eliminar")
            tap("Confirmar eliminación")
            see("Dispositivo eliminado correctamente")
            see("Todavía no tienes dispositivos registrados.")

            tap("Volver a inicio")
            compose.onNodeWithContentDescription("Prototipo del tendedero automático")
                .performScrollTo().assertIsDisplayed()
            compose.onNodeWithText("Contacto institucional · INACAP Talca").performScrollTo().assertIsDisplayed()
            compose.onNodeWithText("Simular lluvia (modo demo)").performScrollTo().performClick()
            compose.onNodeWithText("Recogido").performScrollTo().assertIsDisplayed()
            compose.onNodeWithText("Abrir").assertIsNotEnabled()
            tap("Simular fin de lluvia")
            compose.onNodeWithText("Abrir").assertIsEnabled()
            compose.onNodeWithText("Alertas").performScrollTo().performClick()
            see("Control de alertas")
            compose.onNodeWithText("Conexión").performScrollTo().performClick()
            see("Conexión y eventos")
            compose.onNodeWithText("Historial").performScrollTo().performClick()
            see("Lluvia detectada")
        } finally {
            removeAccount(ctx, address)
            restoreSession(ctx, previous)
        }
    }

    @Test
    fun dispositivosAisladosPorCuentaYSinSesion() {
        val ctx = compose.activity.applicationContext
        val auth = AuthStore(ctx)
        val previous = auth.currentEmail()
        val first = "qa-${UUID.randomUUID()}@example.test"
        val second = "qa-${UUID.randomUUID()}@example.test"
        val password = "PruebaLocal-2026"
        try {
            assertNull(auth.register(first, password))
            val registry = DeviceRegistry(ctx, first)
            val saved = registry.save(null, "  Tendedero A  ", "  Jardín  ", "") as DeviceResult.Saved
            val record = saved.records.single()
            assertEquals("Tendedero A", record.name)
            assertEquals("Jardín", record.place)
            assertNull(auth.register(second, password))
            assertTrue(DeviceRegistry(ctx, second).read().orEmpty().isEmpty())
            assertNull(registry.read())
            assertTrue(registry.delete(record.id) is DeviceResult.Failed)
            auth.logout()
            assertNull(DeviceRegistry(ctx, second).read())
            assertFalse(auth.login(first, "Incorrecta-2026"))
            assertTrue(auth.login(first, password))
            assertEquals(record, DeviceRegistry(ctx, first).read()?.single())
        } finally {
            removeAccount(ctx, first)
            removeAccount(ctx, second)
            restoreSession(ctx, previous)
        }
    }

    private fun tap(text: String) = compose.onNodeWithText(text).performClick()
    private fun see(text: String) = compose.onNodeWithText(text).assertIsDisplayed()

    private fun fillDevice(name: String, place: String) {
        compose.onNodeWithTag("device-name").performTextReplacement(name)
        compose.onNodeWithTag("device-place").performTextReplacement(place)
    }

    private fun removeAccount(context: Context, email: String) {
        val prefs = context.getSharedPreferences("appiot_auth", Context.MODE_PRIVATE)
        val key = prefs.all.entries.firstOrNull { it.value == email && it.key.endsWith("_email") }?.key
        if (key != null) {
            val id = key.removeSuffix("_email")
            val edit = prefs.edit()
            listOf("email", "salt", "algo", "hash").forEach { edit.remove("${id}_$it") }
            edit.commit()
        }
        context.getSharedPreferences("appiot_devices", Context.MODE_PRIVATE).edit().remove(email).commit()
        context.getSharedPreferences("appiot_historial", Context.MODE_PRIVATE).edit().remove(email).commit()
    }

    private fun restoreSession(context: Context, previous: String) {
        val edit = context.getSharedPreferences("appiot_auth", Context.MODE_PRIVATE).edit()
        if (previous.isEmpty()) edit.remove("active_session") else edit.putString("active_session", previous)
        edit.commit()
    }
}

