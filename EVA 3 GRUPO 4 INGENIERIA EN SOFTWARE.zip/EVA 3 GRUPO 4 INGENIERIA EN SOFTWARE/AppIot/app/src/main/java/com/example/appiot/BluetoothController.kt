package com.example.appiot

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID
import java.util.concurrent.Executors

class BluetoothController(
    private val context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onConnectionChanged(connected: Boolean, active: Boolean, deviceName: String, message: String)
        fun onLineReceived(line: String)
        fun onPendingChanged(count: Int)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter

    // El hilo principal conserva el orden de comandos y es dueño de la conexión activa.
    private val pending = ArrayDeque<String>()
    private var device: BluetoothDevice? = null
    private var deviceName = "Sin dispositivo"
    private var socket: BluetoothSocket? = null
    private var connected = false
    private var sending = false
    private val reconnect = Runnable { device?.let(::open) }

    private fun hasPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            context.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    fun isAvailable(): Boolean = adapter != null

    @SuppressLint("MissingPermission")
    fun connectAuthorized(address: String) {
        if (device != null) return
        if (!hasPermission()) {
            publish("Autoriza Dispositivos cercanos")
            return
        }
        val available = adapter
        if (available == null) {
            publish("Este dispositivo no tiene Bluetooth")
            return
        }
        try {
            if (!available.isEnabled) {
                publish("Activa Bluetooth desde Ajustes de Android")
                return
            }
            val preferred = available.bondedDevices.firstOrNull { it.address.equals(address, ignoreCase = true) }
            if (preferred == null) {
                publish("Empareja el módulo registrado desde Ajustes de Android y verifica su dirección")
                return
            }
            device = preferred
            deviceName = preferred.name ?: "Dispositivo Bluetooth"
            open(preferred)
        } catch (_: SecurityException) {
            disconnect("Autoriza Dispositivos cercanos")
        }
    }

    @SuppressLint("MissingPermission")
    fun retainAuthorized(addresses: Set<String>) {
        val active = device ?: return
        if (active.address.uppercase() !in addresses) disconnect("Dispositivo retirado del registro")
    }

    @SuppressLint("MissingPermission")
    private fun open(target: BluetoothDevice) {
        if (!hasPermission()) {
            disconnect("Autoriza Dispositivos cercanos")
            return
        }
        val next = try {
            target.createRfcommSocketToServiceRecord(SPP_UUID)
        } catch (_: Exception) {
            scheduleReconnect()
            publish("Sin conexión. Reintentando…")
            return
        }
        socket = next
        publish("Conectando…")
        io.execute {
            val success = try {
                next.connect()
                true
            } catch (_: Exception) {
                false
            }
            handler.post {
                if (socket !== next) return@post
                if (success) {
                    connected = true
                    publish("Conectado")
                    startReader(next)
                    if ("ESTADO" !in pending) pending.addLast("ESTADO")
                    listener.onPendingChanged(pending.size)
                    sendNext()
                } else {
                    connectionLost(next)
                }
            }
        }
    }

    fun send(command: String): Boolean {
        val clean = command.trim().uppercase()
        if (!connected || clean !in COMMANDS || pending.size >= MAX_PENDIENTES) return false
        if (pending.lastOrNull() != clean) pending.addLast(clean)
        listener.onPendingChanged(pending.size)
        sendNext()
        return true
    }

    private fun sendNext() {
        val active = socket ?: return
        if (!connected || sending) return
        val command = pending.firstOrNull() ?: return
        sending = true
        io.execute {
            val success = try {
                val output = active.outputStream
                output.write((command + "\n").toByteArray(Charsets.UTF_8))
                output.flush()
                true
            } catch (_: Exception) {
                false
            }
            handler.post {
                if (socket !== active) return@post
                sending = false
                if (success) {
                    pending.removeFirst()
                    listener.onPendingChanged(pending.size)
                    sendNext()
                } else {
                    connectionLost(active)
                }
            }
        }
    }

    private fun startReader(active: BluetoothSocket) {
        Thread({
            try {
                active.inputStream.bufferedReader(Charsets.UTF_8).useLines { lines ->
                    lines.map(String::trim).filter(String::isNotEmpty).forEach { line ->
                        handler.post {
                            if (socket === active) listener.onLineReceived(line)
                        }
                    }
                }
            } catch (_: Exception) {
                // Un socket cerrado interrumpe la lectura. El estado se actualiza en el hilo principal.
            } finally {
                handler.post { connectionLost(active) }
            }
        }, "AppIot Bluetooth lectura").start()
    }

    private fun connectionLost(active: BluetoothSocket) {
        if (socket !== active) return
        closeSocket()
        pending.clear()
        listener.onPendingChanged(0)
        publish("Sin conexión. Reintentando…")
        scheduleReconnect()
    }

    private fun scheduleReconnect() {
        handler.removeCallbacks(reconnect)
        if (device != null) handler.postDelayed(reconnect, RECONNECT_DELAY)
    }

    fun disconnect(message: String = "Desconectado") {
        handler.removeCallbacks(reconnect)
        device = null
        deviceName = "Sin dispositivo"
        pending.clear()
        closeSocket()
        listener.onPendingChanged(0)
        publish(message)
    }

    fun close() {
        disconnect()
        io.shutdownNow()
    }

    private fun closeSocket() {
        val previous = socket
        socket = null
        connected = false
        sending = false
        try {
            previous?.close()
        } catch (_: Exception) {
            // Se descarta el socket aunque el sistema ya lo haya cerrado.
        }
    }

    private fun publish(message: String) =
        listener.onConnectionChanged(connected, device != null, deviceName, message)

    companion object {
        private val SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val RECONNECT_DELAY = 5000L
        private const val MAX_PENDIENTES = 25
        private val COMMANDS = setOf(
            "ABRIR", "CERRAR", "ESTADO",
            "BUZZER_ON", "BUZZER_OFF",
            "LED_ON", "LED_OFF",
            "AUTO_ON", "AUTO_OFF"
        )
    }
}
