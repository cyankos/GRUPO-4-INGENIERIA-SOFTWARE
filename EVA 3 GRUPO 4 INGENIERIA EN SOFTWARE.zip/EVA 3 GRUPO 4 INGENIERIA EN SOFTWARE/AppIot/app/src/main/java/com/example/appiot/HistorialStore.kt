package com.example.appiot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

internal class HistorialStore(context: Context) {
    private val prefs = context.getSharedPreferences("appiot_historial", Context.MODE_PRIVATE)

    fun leer(correo: String): List<EventoUi> {
        val guardado = prefs.getString(correo, null) ?: return emptyList()
        return runCatching {
            val lista = JSONArray(guardado)
            List(lista.length()) { indice ->
                val item = lista.getJSONObject(indice)
                EventoUi(item.getString("hora"), item.getString("titulo"), item.getString("detalle"))
            }
        }.getOrDefault(emptyList())
    }

    fun guardar(correo: String, eventos: List<EventoUi>) {
        val lista = JSONArray()
        eventos.forEach {
            lista.put(JSONObject().put("hora", it.hora).put("titulo", it.titulo).put("detalle", it.detalle))
        }
        prefs.edit().putString(correo, lista.toString()).apply()
    }
}
