package com.example.appiot

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

internal class AvisosLluvia(private val context: Context) {
    private val manager = context.getSystemService(NotificationManager::class.java)

    init {
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(CANAL, "Avisos de lluvia", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun notificar() {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        if (!manager.areNotificationsEnabled()) return

        val abrirApp = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val aviso = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, CANAL)
            else Notification.Builder(context)
        manager.notify(ID, aviso
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Lluvia detectada")
            .setContentText("Revisa el estado de tu tendedero.")
            .setContentIntent(abrirApp)
            .setAutoCancel(true)
            .build()
        )
    }

    fun cancelar() = manager.cancel(ID)

    private companion object {
        const val CANAL = "appiot_lluvia"
        const val ID = 1
    }
}
