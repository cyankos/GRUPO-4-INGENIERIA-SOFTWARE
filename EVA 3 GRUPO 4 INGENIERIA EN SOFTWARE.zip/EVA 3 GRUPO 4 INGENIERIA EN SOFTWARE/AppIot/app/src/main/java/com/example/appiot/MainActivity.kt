package com.example.appiot

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.appiot.ui.theme.AppIotTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var bluetoothPermission by mutableStateOf(false)
    private var pendingConnection: (() -> Unit)? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        bluetoothPermission = granted
        val connect = pendingConnection
        pendingConnection = null
        if (granted) connect?.invoke()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        bluetoothPermission = hasBluetoothPermission()

        setContent {
            AppIotTheme(darkTheme = false, dynamicColor = false) {
                Column(
                    Modifier.fillMaxSize().background(Fondo).safeDrawingPadding().imePadding()
                ) {
                    TendederoApp(bluetoothPermission, ::connectWithPermission) {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            startActivity(android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName))
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        bluetoothPermission = hasBluetoothPermission()
    }

    private fun hasBluetoothPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun connectWithPermission(connect: () -> Unit) {
        if (hasBluetoothPermission()) {
            connect()
        } else if (pendingConnection == null) {
            pendingConnection = connect
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
    }
}

data class EventoUi(val hora: String, val titulo: String, val detalle: String)

private val Fondo = Color(0xFFEFF6FC)
private val AzulOscuro = Color(0xFF0C2A50)
private val Azul = Color(0xFF1575CC)
private val Verde = Color(0xFF168A3E)
private val Rojo = Color(0xFFD9363E)
private val Gris = Color(0xFF5D6E81)
private val Borde = Color(0xFFBACDDF)
private val AzulClaro = Color(0xFFE5F0FA)
private val FormaBoton = RoundedCornerShape(10.dp)

@Composable
fun TendederoApp(
    bluetoothPermission: Boolean,
    connectWithPermission: (() -> Unit) -> Unit,
    onNotificationSettings: () -> Unit
) {
    val context = LocalContext.current

    val authStore = remember { AuthStore(context) }
    var correoSesion by remember { mutableStateOf(authStore.currentEmail()) }
    var pantalla by remember { mutableStateOf(if (authStore.hasSession()) "inicio" else "login") }
    var demo by rememberSaveable { mutableStateOf(true) }
    var conectado by remember { mutableStateOf(false) }
    var enlaceActivo by remember { mutableStateOf(false) }
    var dispositivo by remember { mutableStateOf("Sin dispositivo") }
    var detalleConexion by remember {
        mutableStateOf(if (demo) "Modo demostración" else "Conecta el Arduino por Bluetooth")
    }
    var estadoDemo by remember { mutableStateOf(EstadoTendedero.DEMO_INICIAL) }
    var estadoArduino by remember { mutableStateOf(EstadoTendedero()) }
    var pendientes by remember { mutableIntStateOf(0) }
    var opcionesBluetooth by remember { mutableStateOf<List<DeviceRecord>?>(null) }
    val historial = remember { HistorialStore(context) }
    val avisos = remember { AvisosLluvia(context) }
    val eventos = remember { mutableStateListOf<EventoUi>().apply { addAll(historial.leer(correoSesion)) } }
    val estado = if (demo) estadoDemo else estadoArduino
    val controlesActivos = demo || conectado

    fun hora(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    fun registrar(titulo: String, detalle: String) {
        if (correoSesion.isBlank()) return
        eventos.add(0, EventoUi(hora(), titulo, detalle))
        if (eventos.size > 25) eventos.removeAt(eventos.lastIndex)
        historial.guardar(correoSesion, eventos)
    }

    val bluetooth = remember {
        BluetoothController(context.applicationContext, object : BluetoothController.Listener {
            override fun onConnectionChanged(
                connected: Boolean,
                active: Boolean,
                deviceName: String,
                message: String
            ) {
                if (conectado && !connected && active) registrar("Conexión interrumpida", deviceName)
                conectado = connected
                enlaceActivo = active
                dispositivo = deviceName
                detalleConexion = message
                if (connected) {
                    registrar("Arduino conectado", deviceName)
                } else if (!active) {
                    estadoArduino = EstadoTendedero()
                }
            }

            override fun onLineReceived(line: String) {
                val anterior = estadoArduino
                estadoArduino = anterior.aplicarLectura(line)
                when {
                    anterior.lluvia != true && estadoArduino.lluvia == true -> {
                        registrar("Lluvia detectada", "Sensor de agua")
                        avisos.notificar()
                    }
                    anterior.lluvia == true && estadoArduino.lluvia == false ->
                        registrar("Sin lluvia", "Sensor de agua")
                    line.startsWith("OK:", true) ->
                        registrar("Comando confirmado", line.substringAfter(':'))
                    line.startsWith("ERROR:", true) -> registrar("Comando rechazado", line)
                    anterior.recogido != estadoArduino.recogido && estadoArduino.recogido != null ->
                        registrar(if (estadoArduino.recogido == true) "Tendedero recogido" else "Tendedero abierto", "Arduino")
                }
            }

            override fun onPendingChanged(count: Int) {
                pendientes = count
            }
        })
    }

    DisposableEffect(bluetooth) { onDispose { bluetooth.close() } }

    BackHandler(pantalla in setOf("registro", "alertas", "conexion", "historial")) {
        pantalla = if (pantalla == "registro") "login" else "inicio"
    }

    fun enviar(comando: String, titulo: String) {
        if (demo) {
            estadoDemo = estadoDemo.simularComando(comando)
            registrar(titulo, "Modo demostración · $comando")
        } else if (bluetooth.send(comando)) {
            registrar(titulo, "Comando solicitado · $comando")
        } else {
            registrar("Comando no aceptado", comando)
        }
    }

    when (pantalla) {
        "login" -> LoginScreen(
            onEntrar = { email, clave ->
                if (authStore.login(email, clave)) {
                    correoSesion = authStore.currentEmail()
                    eventos.clear()
                    eventos.addAll(historial.leer(correoSesion))
                    pantalla = "inicio"
                    null
                } else {
                    "Correo o contraseña incorrectos"
                }
            },
            onCrearCuenta = { pantalla = "registro" }
        )
        "registro" -> RegistroScreen(
            onRegistrar = { email, clave ->
                val error = authStore.register(email, clave)
                if (error == null) {
                    correoSesion = authStore.currentEmail()
                    eventos.clear()
                    eventos.addAll(historial.leer(correoSesion))
                    pantalla = "inicio"
                }
                error
            },
            onVolver = { pantalla = "login" }
        )
        "inicio" -> InicioScreen(
            correoSesion = correoSesion,
            estado = estado,
            demo = demo,
            controlesActivos = controlesActivos,
            enlaceActivo = enlaceActivo,
            conectado = conectado,
            dispositivo = dispositivo,
            onAbrir = { enviar("ABRIR", "Abrir tendedero") },
            onCerrar = { enviar("CERRAR", "Recoger tendedero") },
            onSimularLluvia = {
                val anterior = estadoDemo
                estadoDemo = estadoDemo.simularLluvia()
                registrar(if (estadoDemo.lluvia == true) "Lluvia detectada" else "Sin lluvia", "Simulación")
                if (anterior.recogido != true && estadoDemo.recogido == true) {
                    registrar("Tendedero recogido", "Modo demostración")
                }
            },
            onBuzzer = { enviar(if (it) "BUZZER_ON" else "BUZZER_OFF", "Buzzer") },
            onLed = { enviar(if (it) "LED_ON" else "LED_OFF", "LED") },
            onAlertas = { pantalla = "alertas" },
            onConexion = { pantalla = "conexion" },
            onHistorial = { pantalla = "historial" },
            onDispositivos = { pantalla = "dispositivos" },
            onCerrarSesion = {
                bluetooth.disconnect()
                demo = true
                estadoDemo = EstadoTendedero.DEMO_INICIAL
                detalleConexion = "Modo demostración"
                eventos.clear()
                authStore.logout()
                avisos.cancelar()
                correoSesion = ""
                pantalla = "login"
            }
        )
        "dispositivos" -> DevicesScreen(correoSesion, onBack = { pantalla = "inicio" }) { records ->
            bluetooth.retainAuthorized(records.map { it.address }.toSet())
        }
        "alertas" -> AlertasScreen(
            estado = estado,
            controlesActivos = controlesActivos,
            onBuzzer = { enviar(if (it) "BUZZER_ON" else "BUZZER_OFF", "Buzzer") },
            onLed = { enviar(if (it) "LED_ON" else "LED_OFF", "LED") },
            onAutomatico = { enviar(if (it) "AUTO_ON" else "AUTO_OFF", "Modo automático") },
            onNotificationSettings = onNotificationSettings,
            onInicio = { pantalla = "inicio" },
            onConexion = { pantalla = "conexion" },
            onHistorial = { pantalla = "historial" }
        )
        "conexion" -> ConexionScreen(
            permiso = bluetoothPermission,
            disponible = bluetooth.isAvailable(),
            conectado = conectado,
            enlaceActivo = enlaceActivo,
            dispositivo = dispositivo,
            detalle = detalleConexion,
            demo = demo,
            pendientes = pendientes,
            eventos = eventos.take(5),
            onDemo = {
                demo = it
                if (it) {
                    bluetooth.disconnect("Modo demostración")
                } else {
                    detalleConexion = "Conecta el Arduino por Bluetooth"
                }
            },
            onConectar = {
                val records = DeviceRegistry(context, correoSesion).read()
                val options = records.orEmpty().filter { it.address.isNotEmpty() }
                when {
                    records == null -> detalleConexion = "No se pudo leer el registro de dispositivos"
                    options.isEmpty() -> detalleConexion = "Registra la dirección Bluetooth en Mis dispositivos"
                    else -> opcionesBluetooth = options
                }
            },
            onDesconectar = { bluetooth.disconnect() },
            onEstado = { enviar("ESTADO", "Estado solicitado") },
            onInicio = { pantalla = "inicio" },
            onAlertas = { pantalla = "alertas" },
            onHistorial = { pantalla = "historial" }
        )
        else -> HistorialScreen(
            eventos = eventos,
            onInicio = { pantalla = "inicio" },
            onAlertas = { pantalla = "alertas" },
            onConexion = { pantalla = "conexion" }
        )
    }

    opcionesBluetooth?.let { opciones ->
        AlertDialog(
            onDismissRequest = { opcionesBluetooth = null },
            title = { Text("Conectar dispositivo autorizado") },
            text = {
                LazyColumn(Modifier.heightIn(max = 230.dp)) {
                    items(opciones, key = { it.id }) { equipo ->
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                opcionesBluetooth = null
                                val cuenta = correoSesion
                                connectWithPermission {
                                    val vigentes = DeviceRegistry(context, cuenta).read().orEmpty()
                                    if (vigentes.any { it.id == equipo.id && it.address == equipo.address }) {
                                        bluetooth.connectAuthorized(equipo.address)
                                    }
                                }
                            }
                        ) { Text("${equipo.name} · ${equipo.address}") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { opcionesBluetooth = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun LoginScreen(
    onEntrar: (String, String) -> String?,
    onCrearCuenta: () -> Unit
) {
    var correo by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var mensajeError by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().background(Fondo).verticalScroll(rememberScrollState()).padding(28.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Spacer(Modifier.height(47.dp))
        Text("Tendedero IoT", fontSize = 31.sp, lineHeight = 37.sp, fontWeight = FontWeight.Bold, color = AzulOscuro)
        Text("Tu ropa segura, sin importar el clima", color = Gris, fontSize = 14.sp)
        Spacer(Modifier.height(35.dp))

        CampoAcceso(
            value = correo,
            onValueChange = { correo = it; mensajeError = "" },
            label = { Text("Correo electrónico") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true,
            isError = mensajeError.isNotBlank(),
            modifier = Modifier.fillMaxWidth().testTag("login-email")
        )
        Spacer(Modifier.height(8.dp))
        CampoAcceso(
            value = clave,
            onValueChange = { clave = it; mensajeError = "" },
            label = { Text("Contraseña") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true,
            isError = mensajeError.isNotBlank(),
            modifier = Modifier.fillMaxWidth().testTag("login-password")
        )
        if (mensajeError.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(mensajeError, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(16.dp))
        Accion(
            onClick = {
                val email = correo.trim()
                mensajeError = when {
                    email.isBlank() || clave.isBlank() -> "Completa correo y contraseña"
                    email.length > 254 || !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Ingresa un correo válido"
                    clave.length > 128 -> "La contraseña admite hasta 128 caracteres"
                    else -> onEntrar(email, clave) ?: ""
                }
            },
            modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
        ) { Text("Iniciar sesión", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(8.dp))
        AccionBorde(onClick = onCrearCuenta, modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)) {
            Text("Crear cuenta", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun RegistroScreen(
    onRegistrar: (String, String) -> String?,
    onVolver: () -> Unit
) {
    var correo by remember { mutableStateOf("") }
    var clave by remember { mutableStateOf("") }
    var confirmar by remember { mutableStateOf("") }
    var mensajeError by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().background(Fondo).verticalScroll(rememberScrollState()).padding(28.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Spacer(Modifier.height(47.dp))
        Text("Crear cuenta", fontSize = 31.sp, lineHeight = 37.sp, fontWeight = FontWeight.Bold, color = AzulOscuro)
        Text("Registra un usuario para acceder al tendedero", color = Gris, fontSize = 14.sp)
        Spacer(Modifier.height(35.dp))
        CampoAcceso(
            value = correo, onValueChange = { correo = it; mensajeError = "" },
            label = { Text("Correo electrónico") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            singleLine = true, modifier = Modifier.fillMaxWidth().testTag("registration-email")
        )
        Spacer(Modifier.height(8.dp))
        CampoAcceso(
            value = clave, onValueChange = { clave = it; mensajeError = "" },
            label = { Text("Contraseña") }, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true, modifier = Modifier.fillMaxWidth().testTag("registration-password")
        )
        Spacer(Modifier.height(8.dp))
        CampoAcceso(
            value = confirmar, onValueChange = { confirmar = it; mensajeError = "" },
            label = { Text("Confirmar contraseña") }, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            singleLine = true, modifier = Modifier.fillMaxWidth().testTag("registration-confirmation")
        )
        if (mensajeError.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(mensajeError, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(16.dp))
        Accion(
            onClick = {
                val email = correo.trim()
                mensajeError = when {
                    email.isBlank() || clave.isBlank() || confirmar.isBlank() -> "Completa todos los campos"
                    email.length > 254 || !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Ingresa un correo válido"
                    clave.length !in 8..128 -> "La contraseña debe tener entre 8 y 128 caracteres"
                    clave != confirmar -> "Las contraseñas no coinciden"
                    else -> onRegistrar(email, clave) ?: ""
                }
            },
            modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp)
        ) { Text("Registrar cuenta", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(8.dp))
        AccionBorde(onClick = onVolver, modifier = Modifier.fillMaxWidth()) { Text("Volver al inicio de sesión") }
    }
}

@Composable
private fun InicioScreen(
    correoSesion: String,
    estado: EstadoTendedero,
    demo: Boolean,
    controlesActivos: Boolean,
    enlaceActivo: Boolean,
    conectado: Boolean,
    dispositivo: String,
    onAbrir: () -> Unit,
    onCerrar: () -> Unit,
    onSimularLluvia: () -> Unit,
    onBuzzer: (Boolean) -> Unit,
    onLed: (Boolean) -> Unit,
    onAlertas: () -> Unit,
    onConexion: () -> Unit,
    onHistorial: () -> Unit,
    onDispositivos: () -> Unit,
    onCerrarSesion: () -> Unit
) {
    val uriHandler = LocalUriHandler.current
    val posicion = when (estado.recogido) {
        true -> "Recogido"
        false -> "Abierto"
        null -> "Sin confirmar"
    }
    val lluvia = when (estado.lluvia) {
        true -> "Detectada"
        false -> "Sin lluvia"
        null -> "Sin lectura"
    }
    val conexion = when {
        demo -> "Demo / desconectado"
        conectado -> dispositivo
        enlaceActivo -> "Conectando con Arduino"
        else -> "Bluetooth desconectado"
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Titulo("Inicio")
        NavBar("Inicio", {}, onAlertas, onConexion, onHistorial)
        AccionBorde(onClick = onDispositivos, modifier = Modifier.fillMaxWidth()) {
            Text("Mis dispositivos", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE4F3FF)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(14.dp)) {
                Text("Estado del tendedero", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(
                    posicion,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (estado.recogido == true) Verde else Azul
                )
                Text(
                    when {
                        estado.recogido == null -> "Esperando lectura del tendedero"
                        !demo && !conectado -> "Último estado recibido"
                        estado.recogido -> "Tendedero protegido"
                        else -> "Tendedero disponible"
                    },
                    color = Gris
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DatoCard("Lluvia", lluvia, when (estado.lluvia) { true -> Rojo; false -> Verde; null -> Gris }, Modifier.weight(1f))
            DatoCard("Sensor A0", estado.sensor, Azul, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DatoCard(
                "Humedad DHT22",
                if (estado.humedad == "--") "--" else "${estado.humedad} %",
                Azul,
                Modifier.weight(1f)
            )
            DatoCard(
                "Temperatura",
                if (estado.temperatura == "--") "--" else "${estado.temperatura} °C",
                Color(0xFFE67E22),
                Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(10.dp))
        DatoCard(
            "Conexión",
            conexion,
            if (conectado) Verde else Gris,
            Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(20.dp))
        Text("Control del tendedero", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = AzulOscuro)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AccionBorde(
                onClick = onAbrir, enabled = controlesActivos && !estado.aperturaBloqueada,
                modifier = Modifier.weight(1f).heightIn(min = 48.dp)
            ) { Text("Abrir") }
            Accion(
                onClick = onCerrar, enabled = controlesActivos,
                modifier = Modifier.weight(1f).heightIn(min = 48.dp)
            ) { Text("Recoger") }
        }
        if (estado.aperturaBloqueada) {
            Text("Apertura bloqueada mientras llueve en modo automático.", color = Rojo)
        }
        if (demo) {
            Spacer(Modifier.height(8.dp))
            AccionBorde(onClick = onSimularLluvia, modifier = Modifier.fillMaxWidth()) {
                Text(if (estado.lluvia == true) "Simular fin de lluvia" else "Simular lluvia (modo demo)")
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Alertas rápidas", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = AzulOscuro)
        SwitchRow("Buzzer", estado.buzzer, onBuzzer, controlesActivos)
        SwitchRow("LED de alerta", estado.led, onLed, controlesActivos)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Image(
                    painterResource(R.drawable.prototipo_tendedero),
                    contentDescription = "Prototipo del tendedero automático",
                    modifier = Modifier.fillMaxWidth().height(135.dp),
                    contentScale = ContentScale.Fit
                )
                Text("Tendedero Automático IoT", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AzulOscuro)
                Text("Detecta lluvia, recoge el tendedero y avisa al celular. Proyecto académico del Grupo 4.", color = Gris)
                AccionBorde(onClick = {
                    runCatching { uriHandler.openUri("https://portal.inacap.cl/admision/contactos-de-admision") }
                }) { Text("Contacto institucional · INACAP Talca") }
                Text("talca@inacap.cl", color = Gris)
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Sesión activa", fontWeight = FontWeight.Bold)
                    Text(correoSesion.ifBlank { "Usuario" }, color = Gris, fontSize = 13.sp)
                }
                AccionBorde(onClick = onCerrarSesion) { Text("Cerrar sesión", fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun AlertasScreen(
    estado: EstadoTendedero,
    controlesActivos: Boolean,
    onBuzzer: (Boolean) -> Unit,
    onLed: (Boolean) -> Unit,
    onAutomatico: (Boolean) -> Unit,
    onNotificationSettings: () -> Unit,
    onInicio: () -> Unit,
    onConexion: () -> Unit,
    onHistorial: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Titulo("Control de alertas")
        if (estado.lluvia == true) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE6E6)), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Lluvia detectada", color = Rojo, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("El modo automático puede recoger el tendedero.", color = Gris)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                SwitchRow("Buzzer", estado.buzzer, onBuzzer, controlesActivos)
                SwitchRow("LED de alerta", estado.led, onLed, controlesActivos)
                SwitchRow("Modo automático", estado.automatico, onAutomatico, controlesActivos)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Seguridad", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = AzulOscuro)
        Text("La aplicación solo envía comandos permitidos y se conecta a un dispositivo Bluetooth previamente emparejado.", color = Gris)
        Spacer(Modifier.height(16.dp))
        NavBar("Alertas", onInicio, {}, onConexion, onHistorial)
        Spacer(Modifier.height(8.dp))
        AccionBorde(onClick = onNotificationSettings, modifier = Modifier.fillMaxWidth()) {
            Text("Avisos de lluvia en Android")
        }
    }
}

@Composable
fun ConexionScreen(
    permiso: Boolean,
    disponible: Boolean,
    conectado: Boolean,
    enlaceActivo: Boolean,
    dispositivo: String,
    detalle: String,
    demo: Boolean,
    pendientes: Int,
    eventos: List<EventoUi>,
    onDemo: (Boolean) -> Unit,
    onConectar: () -> Unit,
    onDesconectar: () -> Unit,
    onEstado: () -> Unit,
    onInicio: () -> Unit,
    onAlertas: () -> Unit,
    onHistorial: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Titulo("Conexión y eventos")
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Bluetooth", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text(if (conectado) "Conectado a $dispositivo" else detalle, color = if (conectado) Verde else Gris)
                Text("Comandos pendientes: $pendientes", color = Gris, fontSize = 13.sp)
                if (!demo && !disponible) Text("Este dispositivo no tiene Bluetooth.", color = Rojo)
                if (!demo && disponible && !permiso) {
                    Text("Autoriza Dispositivos cercanos para conectar.", color = Rojo)
                }
                Spacer(Modifier.height(10.dp))
                SwitchRow("Modo demostración", demo, onDemo)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Accion(
                        onClick = onConectar,
                        enabled = disponible && !demo && !enlaceActivo,
                        modifier = Modifier.weight(1f)
                    ) { Text("Conectar") }
                    AccionBorde(
                        onClick = onDesconectar,
                        enabled = enlaceActivo,
                        modifier = Modifier.weight(1f)
                    ) { Text("Desconectar") }
                }
                AccionBorde(
                    onClick = onEstado,
                    enabled = demo || conectado,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Solicitar estado") }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Continuidad operativa", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = AzulOscuro)
        Text("Si se corta el enlace, la app descarta los comandos pendientes y vuelve a intentar la conexión cada 5 segundos.", color = Gris)
        Spacer(Modifier.height(16.dp))
        Text("Últimos eventos", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = AzulOscuro)
        if (eventos.isEmpty()) Text("Aún no hay eventos.", color = Gris)
        eventos.forEach { EventoCard(it) }
        Spacer(Modifier.height(14.dp))
        NavBar("Conexión", onInicio, onAlertas, {}, onHistorial)
    }
}

@Composable
fun HistorialScreen(
    eventos: List<EventoUi>,
    onInicio: () -> Unit,
    onAlertas: () -> Unit,
    onConexion: () -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Titulo("Historial")
        if (eventos.isEmpty()) {
            Text("No existen eventos todavía.", color = Gris)
        } else {
            eventos.forEach { EventoCard(it) }
        }
        Spacer(Modifier.height(14.dp))
        NavBar("Historial", onInicio, onAlertas, onConexion, {})
    }
}

@Composable
fun Titulo(texto: String) {
    Text(texto, fontSize = 32.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold, color = AzulOscuro)
    Spacer(Modifier.height(9.dp))
}

@Composable
fun DatoCard(titulo: String, valor: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier.heightIn(min = 64.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(titulo, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(valor, color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun SwitchRow(titulo: String, activo: Boolean?, onCambio: (Boolean) -> Unit, habilitado: Boolean = true) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(titulo, fontWeight = FontWeight.Bold)
            val estado = when (activo) {
                true -> "Activo"
                false -> "Desactivado"
                null -> "Sin confirmar"
            }
            Text(estado, color = Gris, fontSize = 13.sp)
        }
        Switch(
            checked = activo == true, onCheckedChange = onCambio, enabled = habilitado && activo != null,
            modifier = Modifier.semantics { contentDescription = titulo }
        )
    }
}

@Composable
fun EventoCard(evento: EventoUi) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(evento.titulo, fontWeight = FontWeight.Bold)
                Text(evento.detalle, color = Gris, fontSize = 13.sp)
            }
            Spacer(Modifier.width(8.dp))
            Text(evento.hora, color = Gris)
        }
    }
}

@Composable
fun NavBar(
    actual: String,
    onInicio: () -> Unit,
    onAlertas: () -> Unit,
    onConexion: () -> Unit,
    onHistorial: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        val destinos = listOf("Inicio" to onInicio, "Alertas" to onAlertas, "Conexión" to onConexion, "Historial" to onHistorial)
        destinos.forEach { (nombre, navegar) ->
            val activo = nombre == actual
            OutlinedButton(
                onClick = navegar,
                modifier = Modifier.weight(1f).semantics { selected = activo },
                shape = FormaBoton,
                contentPadding = PaddingValues(horizontal = 2.dp, vertical = 9.dp),
                border = BorderStroke(1.dp, if (activo) Azul else Borde),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (activo) AzulClaro else Color.White,
                    contentColor = if (activo) Azul else AzulOscuro
                )
            ) { Text(nombre, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
        }
    }
}

@Composable
private fun Accion(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, content: @Composable () -> Unit) {
    Button(onClick = onClick, modifier = modifier, enabled = enabled, shape = FormaBoton) { content() }
}

@Composable
private fun AccionBorde(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, content: @Composable () -> Unit) {
    OutlinedButton(
        onClick = onClick, modifier = modifier, enabled = enabled, shape = FormaBoton,
        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White),
        border = BorderStroke(1.dp, if (enabled) Azul else Borde)
    ) { content() }
}

@Composable
private fun CampoAcceso(
    value: String,
    onValueChange: (String) -> Unit,
    label: @Composable () -> Unit,
    keyboardOptions: KeyboardOptions,
    singleLine: Boolean,
    modifier: Modifier,
    isError: Boolean = false,
    visualTransformation: androidx.compose.ui.text.input.VisualTransformation =
        androidx.compose.ui.text.input.VisualTransformation.None
) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, label = label,
        keyboardOptions = keyboardOptions, singleLine = singleLine,
        modifier = modifier, isError = isError, visualTransformation = visualTransformation,
        shape = FormaBoton,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.White,
            unfocusedContainerColor = Color.White,
            errorContainerColor = Color.White,
            unfocusedBorderColor = Borde,
            unfocusedLabelColor = Gris
        )
    )
}
