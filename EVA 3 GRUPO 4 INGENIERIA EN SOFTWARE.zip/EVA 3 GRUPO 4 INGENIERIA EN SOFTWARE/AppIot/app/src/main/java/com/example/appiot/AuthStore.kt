package com.example.appiot

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class AuthStore(context: Context) {
    private val prefs = context.getSharedPreferences("appiot_auth", Context.MODE_PRIVATE)

    fun register(email: String, password: String): String? {
        val clean = email.trim().lowercase()
        if (userExists(clean)) return "Ese correo ya está registrado"
        createUserInternal(clean, password)
        prefs.edit().putString(KEY_SESSION, clean).apply()
        return null
    }

    fun login(email: String, password: String): Boolean {
        val clean = email.trim().lowercase()
        val id = userId(clean)
        val saltText = prefs.getString("${id}_salt", null) ?: return false
        val expected = prefs.getString("${id}_hash", null) ?: return false
        val algorithm = prefs.getString("${id}_algo", null) ?: preferredAlgorithm()
        val actual = hashPassword(password, Base64.decode(saltText, Base64.NO_WRAP), algorithm)
        val ok = MessageDigest.isEqual(
            Base64.decode(expected, Base64.NO_WRAP),
            Base64.decode(actual, Base64.NO_WRAP)
        )
        if (ok) prefs.edit().putString(KEY_SESSION, clean).apply()
        return ok
    }

    fun logout() {
        prefs.edit().remove(KEY_SESSION).apply()
    }

    fun hasSession(): Boolean = !prefs.getString(KEY_SESSION, null).isNullOrBlank()

    fun currentEmail(): String = prefs.getString(KEY_SESSION, "") ?: ""

    private fun userExists(email: String): Boolean = prefs.contains("${userId(email)}_hash")

    private fun createUserInternal(email: String, password: String) {
        val clean = email.trim().lowercase()
        val id = userId(clean)
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val algorithm = preferredAlgorithm()
        val hash = hashPassword(password, salt, algorithm)
        prefs.edit()
            .putString("${id}_email", clean)
            .putString("${id}_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("${id}_hash", hash)
            .putString("${id}_algo", algorithm)
            .apply()
    }

    private fun preferredAlgorithm(): String {
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            "PBKDF2WithHmacSHA256"
        } catch (_: Exception) {
            "PBKDF2WithHmacSHA1"
        }
    }

    private fun hashPassword(password: String, salt: ByteArray, algorithm: String): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 60000, 256)
        return try {
            val factory = SecretKeyFactory.getInstance(algorithm)
            Base64.encodeToString(factory.generateSecret(spec).encoded, Base64.NO_WRAP)
        } finally {
            spec.clearPassword()
        }
    }

    private fun userId(email: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(email.trim().lowercase().toByteArray())
        return digest.joinToString("") { "%02x".format(it) }.take(24)
    }

    companion object {
        private const val KEY_SESSION = "active_session"
    }
}
