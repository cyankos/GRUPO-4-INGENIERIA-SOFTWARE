package com.example.appiot

import android.content.Context
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.util.UUID

internal data class DeviceRecord(val id: String, val name: String, val place: String, val address: String)

internal data class DeviceErrors(val name: String? = null, val place: String? = null, val address: String? = null) {
    val hasErrors get() = name != null || place != null || address != null
}

private val macFormat = Regex("([0-9A-F]{2}:){5}[0-9A-F]{2}")

internal fun deviceErrors(name: String, place: String, address: String, devices: List<DeviceRecord>, editingId: String?) =
    DeviceErrors(
        name = when {
            name.trim().length !in 3..40 || name.any(Char::isISOControl) ->
                "Escribe un nombre de 3 a 40 caracteres"
            devices.any { it.id != editingId && it.name.equals(name.trim(), ignoreCase = true) } ->
                "Ya existe un dispositivo con ese nombre"
            else -> null
        },
        place = if (place.trim().length !in 2..60 || place.any(Char::isISOControl)) {
            "Escribe una ubicación de 2 a 60 caracteres"
        } else null,
        address = when {
            address.isEmpty() -> null
            !macFormat.matches(address) || address == "00:00:00:00:00:00" || address == "FF:FF:FF:FF:FF:FF" ->
                "Usa una MAC válida, por ejemplo 12:34:56:78:9A:BC"
            devices.any { it.id != editingId && it.address == address } ->
                "Esa dirección Bluetooth ya está registrada"
            else -> null
        }
    )

internal sealed interface DeviceResult {
    data class Saved(val records: List<DeviceRecord>) : DeviceResult
    data class Invalid(val errors: DeviceErrors) : DeviceResult
    data class Failed(val message: String) : DeviceResult
}

internal class DeviceRegistry(context: Context, private val account: String) {
    private val auth = AuthStore(context)
    private val prefs = context.getSharedPreferences("appiot_devices", Context.MODE_PRIVATE)

    fun read(): List<DeviceRecord>? = synchronized(lock) {
        if (hasAccess()) readRecords() else null
    }

    fun save(id: String?, name: String, place: String, address: String): DeviceResult = synchronized(lock) {
        if (!hasAccess()) return@synchronized DeviceResult.Failed("Inicia sesión para continuar")
        val records = readRecords() ?: return@synchronized unreadable()
        val normalizedAddress = address.trim().uppercase()
        val errors = deviceErrors(name, place, normalizedAddress, records, id)
        if (errors.hasErrors) return@synchronized DeviceResult.Invalid(errors)
        val index = records.indexOfFirst { it.id == id }
        if (id != null && index == -1) return@synchronized DeviceResult.Failed("El dispositivo ya no existe")
        if (id == null && records.size >= 100) return@synchronized DeviceResult.Failed("Límite de 100 dispositivos")
        val record = DeviceRecord(id ?: UUID.randomUUID().toString(), name.trim(), place.trim(), normalizedAddress)
        val updated = records.toMutableList()
        if (index == -1) updated.add(record) else updated[index] = record
        persist(updated)
    }

    fun delete(id: String): DeviceResult = synchronized(lock) {
        if (!hasAccess()) return@synchronized DeviceResult.Failed("Inicia sesión para continuar")
        val records = readRecords() ?: return@synchronized unreadable()
        val updated = records.filterNot { it.id == id }
        if (records.size == updated.size) DeviceResult.Failed("El dispositivo ya no existe") else persist(updated)
    }

    private fun hasAccess() = account.isNotBlank() && account == auth.currentEmail()

    private fun readRecords(): List<DeviceRecord>? = try {
        val array = JSONArray(prefs.getString(account, null) ?: "[]")
        List(array.length()) { index ->
            val item = array.getJSONObject(index)
            DeviceRecord(item.getString("id"), item.getString("name"), item.getString("place"), item.optString("address"))
        }
    } catch (_: JSONException) {
        null
    }

    private fun unreadable() = DeviceResult.Failed("No se pudo leer el registro de dispositivos")

    private fun persist(records: List<DeviceRecord>): DeviceResult {
        val data = JSONArray()
        records.forEach {
            data.put(JSONObject().put("id", it.id).put("name", it.name).put("place", it.place).put("address", it.address))
        }
        return if (prefs.edit().putString(account, data.toString()).commit()) {
            DeviceResult.Saved(records)
        } else {
            DeviceResult.Failed("No se pudo guardar el cambio")
        }
    }

    private companion object {
        val lock = Any()
    }
}
