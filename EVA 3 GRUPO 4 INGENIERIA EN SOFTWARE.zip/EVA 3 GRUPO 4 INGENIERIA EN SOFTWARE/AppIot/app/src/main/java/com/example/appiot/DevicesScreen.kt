package com.example.appiot

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
internal fun DevicesScreen(account: String, onBack: () -> Unit, onChanged: (List<DeviceRecord>) -> Unit) {
    val context = LocalContext.current
    val registry = remember(account) { DeviceRegistry(context, account) }
    var records by remember(registry) { mutableStateOf(registry.read()) }
    var editing by remember { mutableStateOf<DeviceRecord?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<DeviceRecord?>(null) }
    var notice by remember { mutableStateOf("") }
    var failed by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp)) {
        Titulo("Mis dispositivos")
        Text("Registra tus tendederos y autoriza la conexión por dirección Bluetooth.")
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Volver a inicio") }
            Button(
                onClick = { notice = ""; editing = null; showForm = true },
                modifier = Modifier.weight(1f),
                enabled = records != null
            ) { Text("Agregar dispositivo") }
        }
        if (notice.isNotEmpty()) {
            Text(
                notice,
                Modifier.padding(bottom = 10.dp).semantics { liveRegion = LiveRegionMode.Polite },
                color = if (failed) MaterialTheme.colorScheme.error else Color(0xFF146A35),
                fontWeight = FontWeight.SemiBold
            )
        }
        val list = records
        when {
            list == null -> Text("No se pudo leer el registro.", color = MaterialTheme.colorScheme.error)
            list.isEmpty() -> Text("Todavía no tienes dispositivos registrados.")
            else -> LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(list, key = { it.id }) { record ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(record.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(record.place)
                            Text(record.address.ifEmpty { "Registro de demostración" })
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { notice = ""; editing = record; showForm = true }) { Text("Editar") }
                                TextButton(onClick = { notice = ""; deleting = record }) {
                                    Text("Eliminar", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        val current = editing
        DeviceForm(current, onClose = { showForm = false }) { name, place, address ->
            val result = registry.save(current?.id, name, place, address)
            if (result is DeviceResult.Saved) {
                records = result.records
                onChanged(result.records)
                failed = false
                notice = if (current == null) "Dispositivo agregado correctamente" else "Cambios guardados correctamente"
                showForm = false
            }
            result
        }
    }

    deleting?.let { record ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Eliminar dispositivo") },
            text = { Text("¿Quieres eliminar “${record.name}” de tu registro?") },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } },
            confirmButton = {
                TextButton(onClick = {
                    when (val result = registry.delete(record.id)) {
                        is DeviceResult.Saved -> {
                            records = result.records
                            onChanged(result.records)
                            failed = false
                            notice = "Dispositivo eliminado correctamente"
                        }
                        is DeviceResult.Failed -> {
                            failed = true
                            notice = result.message
                        }
                        is DeviceResult.Invalid -> Unit
                    }
                    deleting = null
                }) { Text("Confirmar eliminación", color = MaterialTheme.colorScheme.error) }
            }
        )
    }
}

@Composable
private fun DeviceForm(record: DeviceRecord?, onClose: () -> Unit, onSave: (String, String, String) -> DeviceResult) {
    var name by remember { mutableStateOf(record?.name.orEmpty()) }
    var place by remember { mutableStateOf(record?.place.orEmpty()) }
    var address by remember { mutableStateOf(record?.address.orEmpty()) }
    var errors by remember { mutableStateOf(DeviceErrors()) }
    var failure by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (record == null) "Agregar dispositivo" else "Editar dispositivo") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errors = errors.copy(name = null); failure = "" },
                    label = { Text("Nombre del tendedero") },
                    singleLine = true,
                    isError = errors.name != null,
                    supportingText = errors.name?.let { message -> { Text(message) } },
                    modifier = Modifier.fillMaxWidth().testTag("device-name")
                )
                OutlinedTextField(
                    value = place,
                    onValueChange = { place = it; errors = errors.copy(place = null); failure = "" },
                    label = { Text("Ubicación") },
                    singleLine = true,
                    isError = errors.place != null,
                    supportingText = errors.place?.let { message -> { Text(message) } },
                    modifier = Modifier.fillMaxWidth().testTag("device-place")
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it; errors = errors.copy(address = null); failure = "" },
                    label = { Text("Dirección Bluetooth") },
                    singleLine = true,
                    isError = errors.address != null,
                    supportingText = { Text(errors.address ?: "Opcional para dispositivos de demostración") },
                    modifier = Modifier.fillMaxWidth().testTag("device-address")
                )
                if (failure.isNotEmpty()) Text(failure, color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancelar") } },
        confirmButton = {
            TextButton(onClick = {
                when (val result = onSave(name, place, address)) {
                    is DeviceResult.Invalid -> errors = result.errors
                    is DeviceResult.Failed -> failure = result.message
                    is DeviceResult.Saved -> Unit
                }
            }) { Text(if (record == null) "Guardar dispositivo" else "Guardar cambios") }
        }
    )
}
