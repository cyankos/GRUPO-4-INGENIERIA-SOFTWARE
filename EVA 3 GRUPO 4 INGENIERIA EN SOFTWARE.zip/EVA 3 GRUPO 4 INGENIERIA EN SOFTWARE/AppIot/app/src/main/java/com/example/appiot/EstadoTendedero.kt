package com.example.appiot

internal data class EstadoTendedero(
    val lluvia: Boolean? = null,
    val sensor: String = "--",
    val humedad: String = "--",
    val temperatura: String = "--",
    val recogido: Boolean? = null,
    val buzzer: Boolean? = null,
    val led: Boolean? = null,
    val automatico: Boolean? = null
) {
    fun simularLluvia(): EstadoTendedero {
        val lloviendo = lluvia != true
        return copy(
            lluvia = lloviendo,
            sensor = if (lloviendo) "650" else "0",
            humedad = if (lloviendo) "88.0" else "62.0",
            temperatura = if (lloviendo) "17.8" else "20.4",
            recogido = if (lloviendo && automatico == true) true else recogido
        )
    }

    fun simularComando(comando: String): EstadoTendedero = when (comando) {
        "ABRIR" -> if (aperturaBloqueada) this else copy(recogido = false)
        "CERRAR" -> copy(recogido = true)
        "BUZZER_ON" -> copy(buzzer = true)
        "BUZZER_OFF" -> copy(buzzer = false)
        "LED_ON" -> copy(led = true)
        "LED_OFF" -> copy(led = false)
        "AUTO_ON" -> copy(automatico = true, recogido = if (lluvia == true) true else recogido)
        "AUTO_OFF" -> copy(automatico = false)
        else -> this
    }

    val aperturaBloqueada: Boolean get() = lluvia == true && automatico == true

    fun aplicarLectura(linea: String): EstadoTendedero {
        val dato = linea.substringAfter(':', "").trim().uppercase()
        if (dato.isEmpty()) return this

        return when (linea.substringBefore(':').trim().uppercase()) {
            "LLUVIA" -> when (dato) {
                "0" -> copy(lluvia = false)
                "1" -> copy(lluvia = true)
                else -> this
            }
            "SENSOR" -> if (dato.toIntOrNull() in 0..1023) copy(sensor = dato) else this
            "HUM" -> if (dato == "NA" || dato.toDoubleOrNull()?.let { it in 0.0..100.0 } == true) {
                copy(humedad = if (dato == "NA") "--" else dato)
            } else this
            "TEMP" -> if (dato == "NA" || dato.toDoubleOrNull()?.let { it in -40.0..80.0 } == true) {
                copy(temperatura = if (dato == "NA") "--" else dato)
            } else this
            "TENDEDERO" -> when (dato) {
                "ABIERTO" -> copy(recogido = false)
                "RECOGIDO", "CERRADO" -> copy(recogido = true)
                else -> this
            }
            "BUZZER" -> comoInterruptor(dato)?.let { copy(buzzer = it) } ?: this
            "LED" -> comoInterruptor(dato)?.let { copy(led = it) } ?: this
            "AUTO" -> comoInterruptor(dato)?.let { copy(automatico = it) } ?: this
            else -> this
        }
    }

    private fun comoInterruptor(valor: String): Boolean? = when (valor) {
        "ON" -> true
        "OFF" -> false
        else -> null
    }

    companion object {
        val DEMO_INICIAL = EstadoTendedero(
            lluvia = false,
            sensor = "0",
            humedad = "62.0",
            temperatura = "20.4",
            recogido = false,
            buzzer = true,
            led = true,
            automatico = true
        )
    }
}
